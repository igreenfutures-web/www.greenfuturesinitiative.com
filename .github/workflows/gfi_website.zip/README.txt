Green Futures Initiative (GFI) - Static WordPress-style Theme (One-page)
---------------------------------------------------------------------
Files included:
  - index.html        (main page)
  - assets/css/style.css
  - assets/js/script.js
  - assets/images/*   (your photos)

How to use:
1) To host as static site (Netlify or GitHub Pages):
   - Upload the entire 'gfi_website' folder to Netlify Drop or push to a GitHub repo and enable Pages.
2) To convert to simple WordPress theme:
   - Rename index.html to front-page.php, split header/footer into header.php/footer.php and place in a WP theme folder with style.css.
   - This requires WordPress knowledge and a PHP-enabled host.
3) To edit content:
   - Open index.html in any text editor and replace text and images in assets/images.

Contact:
  Byegarazo Pius
  Igreenfutures@gmail.com